<?php

// zamena vrenosti unutar varijable

$marka = "Nissan";

$marka = str_replace("s", "S", $marka);

echo $marka;




// Provera da li je broj 0

// Ukoliko jeste izbaci text 

// die = CODE STOP !!!

// NE PIŠI FUNCKIJE UNUTAR KOMENTARA !!!


function spojiBrojeve($prviBroj, $drugiBroj)
{
    if($prviBroj == 0 || $drugiBroj == 0)  
    {
        die("Broj ne sme biti 0");
    }
    else echo $prviBroj+$drugiBroj;
}

spojiBrojeve(20,123);





// >>> str_replace je vec gotova i definisana funkcija.
// >>> Kada bismo želeli da ovu funkciju prevedemo u buvalni kod i shvatili šta ona radi u pozadini, koraci bi bili sledeci:

//                >>> Vec navedeni primer bi se pretvorio u array sa rasparčanim slovima    $marka = "Nissan;"  


//                               $marka = ["N", "i", "s", "s", "a", "n"]

                                           
//                >>> Na array bi se primenila foreach petlja koja bi definisala pojedine delove arraya kao ZASEBNO SLOVO.

//                               foreach($marka as $slovo)

//                >>> A onda bi se UNUTAR foreach petlje dodali if i else if (conditional statements) 


//                               foreach($marka as $slovo)
//                                  {
//                                   if($slovo == "s")
//                                    {
//                                     $slovo == "S";
//                                    }
//                                   }





?>



