<?php

// Porez kalkulator

function izracunajPorez($cena)
{
    
    $stopaPoreza = 0.22;
    $proveraStringa = is_string($cena);

    if($cena <= 1) 
    {
        die ("Uneta cena mora biti veća od 1 eur");
    }
    else if ($proveraStringa == 1) 
    {
        die ("Cena mora biti definisana brojevima");
    }
    else 
    {
        echo $cena*$stopaPoreza;
    }
}

izracunajPorez(124);





//  provera da li je varijabla string

$test = "tekst";
$proveraVarijable = is_string($test);
echo $proveraVarijable;

// Vraca odgovor (bool) 1 = DA, 0 = NE



?>