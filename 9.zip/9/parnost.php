<?php

// Provera parnosti broja

function proveraParnosti($broj)
{
    $rezultat = $broj%2;

    if($broj == 0) 
    {
        die ("Broj ne sme biti 0");
    }
    else if($rezultat == 0) 
    {
        echo "Broj $broj je paran broj";
    }

    else echo "Broj $broj je neparan broj";
}


proveraParnosti(23);
proveraParnosti(55);
proveraParnosti(17);
proveraParnosti(1277);
proveraParnosti(9226351);



?>